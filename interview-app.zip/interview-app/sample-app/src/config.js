const config = {
    earthQuakesApi: process.env.EARTH_QUAKES_API || 'http://localhost:3001'
};
export default config;