const config = {
    usgsPublicApi: 'TODO'//https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson
};
module.exports = config;